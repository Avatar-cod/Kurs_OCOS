Вариант 9. Запуск из папки архива:
python -m pip install -r requirements.txt
python main.py --config config.json --no-show
Результаты нового запуска: results/. Готовый расчёт: seismic_results/.
