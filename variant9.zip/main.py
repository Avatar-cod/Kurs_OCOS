import argparse
import csv
import json
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import fftconvolve
from scipy.fft import rfft, rfftfreq

DEFAULT = dict(A5=1.0, A15=0.6, alpha5=0.2, alpha15=0.5,
               duration=10.0, fs_ref=4200, noise_level=0.5,
               noise_low=0.5, noise_high=2.0, seed=42, tolerance=5.0)
KS = [4.0, 2.0, 1.0, 0.7, 0.5]
BITS = [8, 10, 12, 16, 20]


def sinc(u):
    """Normalized sinc, implemented without np.sinc."""
    u = np.asarray(u, dtype=float)
    return np.divide(np.sin(np.pi*u), np.pi*u,
                     out=np.ones_like(u), where=u != 0)


def restore(samples, step, n):
    """Finite Shannon sum on the reference grid, using FFT convolution."""
    impulses = np.zeros(n)
    impulses[::step] = samples
    offsets = np.arange(-(n-1), n)
    kernel = sinc(offsets / step)
    return fftconvolve(impulses, kernel, mode='same')


def quantize(x, b, limit):
    levels = 2**b
    delta = 2*limit/(levels-1)
    return np.round((np.clip(x, -limit, limit)+limit)/delta)*delta-limit


def spectrum(x, fs):
    a = np.abs(rfft(x))/len(x)
    a[1:] *= 2
    if len(x) % 2 == 0:
        a[-1] /= 2
    return rfftfreq(len(x), 1/fs), a


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=Path)
    parser.add_argument('--output', type=Path, default=Path('results'))
    parser.add_argument('--no-show', action='store_true')
    args = parser.parse_args()
    p = DEFAULT.copy()
    if args.config:
        p.update(json.loads(args.config.read_text(encoding='utf-8')))
    out = args.output
    out.mkdir(parents=True, exist_ok=True)
    fs0 = p['fs_ref']
    n = round(p['duration']*fs0)
    if n < 2 or p['A5'] <= 0 or p['A15'] <= 0:
        raise ValueError('Duration and amplitudes must be positive.')
    if not 0 < p['noise_low'] < p['noise_high'] < fs0/2:
        raise ValueError('Invalid noise frequency band.')
    t = np.arange(n)/fs0
    basis = np.column_stack((np.exp(-p['alpha5']*t)*np.sin(2*np.pi*5*t),
                             np.exp(-p['alpha15']*t)*np.sin(2*np.pi*15*t)))
    clean = basis @ [p['A5'], p['A15']]
    rng = np.random.default_rng(p['seed'])
    freq = rfftfreq(n, 1/fs0)
    noise_fft = rfft(rng.normal(size=n))
    noise_fft[(freq < p['noise_low']) | (freq > p['noise_high'])] = 0
    from scipy.fft import irfft
    noise = irfft(noise_fft, n=n)
    peak = np.max(np.abs(noise))
    if peak == 0:
        raise ValueError('No FFT bins in noise band; increase duration.')
    noise *= p['noise_level']*np.max(np.abs(clean))/peak
    analog = clean + noise
    limit = np.max(np.abs(analog))*1.05
    true_ratio = p['A5']/p['A15']
    rows, examples, sampled = [], {}, {}
    for k in KS:
        fs = 30*k
        step = round(fs0/fs)
        if step < 1 or not np.isclose(fs0/step, fs):
            raise ValueError('fs_ref must be divisible by every Fs (e.g. 4200).')
        samples = analog[::step]
        sampled[k] = samples
        # At 30 and 15 Hz the specified 15 Hz sine is sampled at its zeros.
        observable = np.linalg.norm(basis[::step, 1]) > 1e-8
        for b in BITS:
            q = quantize(samples, b, limit)
            recovered = restore(q, step, n)
            # Estimate initial amplitudes using the known damped-sine templates.
            a5, a15 = np.linalg.lstsq(basis, recovered, rcond=None)[0]
            ratio = abs(a5/a15) if observable and abs(a15) > 1e-12 else np.nan
            error = 100*abs(ratio-true_ratio)/true_ratio
            rows.append(dict(K=k, b=b, Fs=fs, bitrate=fs*b, A5=a5,
                             A15=a15, ratio=ratio, error_pct=error,
                             observable=bool(observable)))
            if b == 12 and k in (4.0, 1.0, 0.7):
                examples[k] = recovered
    valid = [r for r in rows if np.isfinite(r['error_pct'])]
    for r in rows:
        r['pareto'] = bool(np.isfinite(r['error_pct']) and not any(
            s['bitrate'] <= r['bitrate'] and s['error_pct'] <= r['error_pct']
            and (s['bitrate'] < r['bitrate'] or s['error_pct'] < r['error_pct'])
            for s in valid))
    front = sorted([r for r in rows if r['pareto']], key=lambda r:r['bitrate'])
    feasible = [r for r in front if r['error_pct'] <= p['tolerance']]
    best = min(feasible, key=lambda r:(r['bitrate'], r['error_pct'])) if feasible else None
    with (out/'results.csv').open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print('K      b     Fs     bit/s       error (%)')
    for r in rows:
        print(f"{r['K']:4.1f} {r['b']:4d} {r['Fs']:6.1f} {r['bitrate']:9.1f} {r['error_pct']:12.5f}")
    print('Reference ratio:', true_ratio)
    print('Optimal:', best if best else 'No feasible point')
    print('nan = diagnostic ratio not identifiable / undefined')

    fig, axes = plt.subplots(3, 1, figsize=(10, 9), sharex=True)
    for ax, (k, y) in zip(axes, examples.items()):
        ax.plot(t, clean, label='Clean reference')
        ax.plot(t, analog, alpha=.4, label='ADC input')
        ax.plot(t, y, '--', label='Recovered, 12 bit')
        ax.set(title=f'K={k}, Fs={30*k:g} Hz', ylabel='Amplitude', xlim=(0,min(2,t[-1])))
        ax.grid(alpha=.3); ax.legend()
    axes[-1].set_xlabel('Time, s')
    fig.tight_layout(); fig.savefig(out/'signals.png', dpi=150)

    fig, axes = plt.subplots(3, 1, figsize=(10, 9))
    f, a = spectrum(analog, fs0)
    for ax, k in zip(axes, examples):
        fd, ad = spectrum(sampled[k], 30*k)
        ax.plot(f, a, label='Before sampling')
        ax.plot(fd, ad, 'o-', ms=2, label='After sampling')
        ax.axvline(15*k, ls=':', color='gray', label='Nyquist frequency')
        ax.set(title=f'K={k}', xlim=(0,max(20,15*k+1)), ylabel='Amplitude')
        ax.grid(alpha=.3); ax.legend()
    axes[-1].set_xlabel('Frequency, Hz')
    fig.tight_layout(); fig.savefig(out/'spectra.png', dpi=150)

    fig, ax = plt.subplots(figsize=(9, 5))
    for k in KS:
        rr = [r for r in rows if r['K']==k]
        if any(np.isfinite(r['error_pct']) for r in rr):
            ax.plot(BITS, [r['error_pct'] for r in rr], 'o-', label=f'K={k}')
    ax.axhline(p['tolerance'], ls='--', color='gray', label='Tolerance')
    ax.set(xlabel='ADC bits', ylabel='Ratio error, %', xticks=BITS, yscale='symlog')
    ax.grid(alpha=.3); ax.legend(); fig.tight_layout()
    fig.savefig(out/'errors.png', dpi=150)

    fig, ax = plt.subplots(figsize=(9, 5))
    matrix = np.array([[r['error_pct'] for r in rows if r['K']==k] for k in KS])
    im = ax.imshow(np.ma.masked_invalid(np.log10(1+matrix)), aspect='auto')
    for i in range(len(KS)):
        for j in range(len(BITS)):
            v = matrix[i,j]
            ax.text(j,i,f'{v:.2f}' if np.isfinite(v) else 'N/A', ha='center', va='center',
                    color='white' if not np.isfinite(v) or np.log10(1+v)<2 else 'black')
    ax.set(xticks=range(len(BITS)), xticklabels=BITS, yticks=range(len(KS)), yticklabels=KS,
           xlabel='ADC bits', ylabel='K', title='Relative error (%)')
    fig.colorbar(im, ax=ax, label='log10(1 + error %)')
    fig.tight_layout(); fig.savefig(out/'error_matrix.png', dpi=150)

    fig, ax = plt.subplots(figsize=(9, 5))
    ax.scatter([r['bitrate'] for r in valid], [r['error_pct'] for r in valid], label='All valid points')
    ax.plot([r['bitrate'] for r in front], [r['error_pct'] for r in front], 'o-', label='Pareto front')
    ax.axhline(p['tolerance'], ls='--', color='gray', label='Tolerance')
    if best:
        ax.scatter(best['bitrate'], best['error_pct'], marker='*', s=220, label='Optimal')
        ax.annotate(f"K={best['K']}, b={best['b']}", (best['bitrate'], best['error_pct']), xytext=(8,12), textcoords='offset points')
    ax.set(xlabel='Data rate, bit/s', ylabel='Ratio error, %', yscale='symlog')
    ax.grid(alpha=.3); ax.legend(); fig.tight_layout()
    fig.savefig(out/'pareto.png', dpi=150)
    if not args.no_show:
        plt.show()
    plt.close('all')


if __name__ == '__main__':
    main()
